function toggleMenu(id) {
    const menu = document.getElementById(id);
    menu.style.display = (menu.style.display === 'flex') ? 'none' : 'flex';
}
